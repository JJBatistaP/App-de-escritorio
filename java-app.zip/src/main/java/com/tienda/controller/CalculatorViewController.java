package com.tienda.controller;

import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

public class CalculatorViewController {

    // Input fields for inventory calculation
    private TextField invInicialField;
    private TextField entradaField;
    private TextField mermaField;
    private TextField ventaField;
    private TextField invFinalField;

    // UI components
    private Button calculateBtn;
    private Label resultLabel;
    private Label modeLabel;

    public VBox createView() {
        initializeComponents();

        VBox mainVBox = new VBox(15);
        mainVBox.setStyle("-fx-padding: 20;");

        Label titleLabel = new Label("Calculadora de Inventario");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        mainVBox.getChildren().add(titleLabel);

        // Create input grid
        GridPane inputGrid = new GridPane();
        inputGrid.setHgap(10);
        inputGrid.setVgap(10);

        // Row 0: Labels
        inputGrid.add(new Label("Inventario Inicial:"), 0, 0);
        inputGrid.add(new Label("Entradas:"), 0, 1);
        inputGrid.add(new Label("Merma/Pérdidas:"), 0, 2);
        inputGrid.add(new Label("Ventas (opcional):"), 0, 3);
        inputGrid.add(new Label("Inventario Final (opcional):"), 0, 4);

        // Row 1: Input fields
        inputGrid.add(invInicialField, 1, 0);
        inputGrid.add(entradaField, 1, 1);
        inputGrid.add(mermaField, 1, 2);
        inputGrid.add(ventaField, 1, 3);
        inputGrid.add(invFinalField, 1, 4);

        mainVBox.getChildren().add(inputGrid);

        // Calculate button
        mainVBox.getChildren().add(calculateBtn);

        // Results section
        VBox resultsBox = new VBox(5);
        resultsBox.getChildren().addAll(modeLabel, resultLabel);
        mainVBox.getChildren().add(resultsBox);

        return mainVBox;
    }

    private void initializeComponents() {
        // Initialize input fields
        invInicialField = new TextField();
        invInicialField.setPromptText("0");
        invInicialField.setPrefWidth(150);

        entradaField = new TextField();
        entradaField.setPromptText("0");
        entradaField.setPrefWidth(150);

        mermaField = new TextField();
        mermaField.setPromptText("0");
        mermaField.setPrefWidth(150);

        ventaField = new TextField();
        ventaField.setPromptText("Dejar vacío para calcular");
        ventaField.setPrefWidth(150);

        invFinalField = new TextField();
        invFinalField.setPromptText("Dejar vacío para calcular");
        invFinalField.setPrefWidth(150);

        // Initialize UI components
        calculateBtn = new Button("Calcular");
        calculateBtn.setOnAction(e -> performCalculation());

        resultLabel = new Label("Resultado aparecerá aquí");
        resultLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        modeLabel = new Label("Modo de cálculo: Pendiente");
        modeLabel.setStyle("-fx-font-size: 12px;");
    }

    private void performCalculation() {
        try {
            // Parse input values
            double invInicial = parseDouble(invInicialField.getText());
            double entrada = parseDouble(entradaField.getText());
            double merma = parseDouble(mermaField.getText());

            String ventaText = ventaField.getText().trim();
            String invFinalText = invFinalField.getText().trim();

            boolean hasVenta = !ventaText.isEmpty();
            boolean hasInvFinal = !invFinalText.isEmpty();

            double venta = 0;
            double invFinal = 0;

            if (hasVenta) {
                venta = parseDouble(ventaText);
            }
            if (hasInvFinal) {
                invFinal = parseDouble(invFinalText);
            }

            // Determine calculation mode
            if (hasVenta && hasInvFinal) {
                // Both provided - prioritize final inventory calculation
                double calculatedInvFinal = invInicial + entrada - merma - venta;
                modeLabel.setText("Modo: Cálculo de Inventario Final (ambos valores proporcionados)");
                resultLabel.setText(String.format("Inventario Final Calculado: %.2f", calculatedInvFinal));
            } else if (!hasVenta && hasInvFinal) {
                // Missing venta - calculate sales
                venta = invInicial + entrada - merma - invFinal;
                modeLabel.setText("Modo: Cálculo de Ventas");
                resultLabel.setText(String.format("Ventas Calculadas: %.2f", venta));
            } else if (hasVenta && !hasInvFinal) {
                // Missing inv_final - calculate final inventory
                invFinal = invInicial + entrada - merma - venta;
                modeLabel.setText("Modo: Cálculo de Inventario Final");
                resultLabel.setText(String.format("Inventario Final Calculado: %.2f", invFinal));
            } else {
                // Neither provided - error
                modeLabel.setText("Modo: Error - Datos insuficientes");
                resultLabel.setText("Error: Debe proporcionar Ventas O Inventario Final para calcular");
                return;
            }

        } catch (NumberFormatException e) {
            modeLabel.setText("Modo: Error - Datos inválidos");
            resultLabel.setText("Error: Verifique que todos los campos numéricos sean válidos");
        } catch (Exception e) {
            modeLabel.setText("Modo: Error");
            resultLabel.setText("Error inesperado: " + e.getMessage());
        }
    }

    private double parseDouble(String text) throws NumberFormatException {
        if (text == null || text.trim().isEmpty()) {
            return 0.0;
        }
        return Double.parseDouble(text.trim());
    }
}
